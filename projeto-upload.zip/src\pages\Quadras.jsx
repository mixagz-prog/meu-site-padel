// src/pages/Quadras.jsx
import { motion } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import { useToast } from "../context/ToastContext.jsx";
import { useAuth } from "../context/AuthContext";

/* Guardar origem para retorno pós-login */
function saveFrom(location){
  const from = { pathname: location.pathname, search: location.search, hash: location.hash, state: location.state ?? null };
  try { sessionStorage.setItem("auth.from", JSON.stringify(from)); } catch {}
  return from;
}

const COURTS = [
  {
    id: "indoor-pro",
    name: "Quadra Indoor Pro",
    subtitle: "Estrutura galvanizada a quente + pintura eletrostática dupla, vidro 12 mm certificado",
    priceStart: "a partir de R$ 189.000",
    leadTime: "Instalação em 30–60 dias",
    highlights: ["Vidro 12 mm (EN 12150-1)", "Estrutura com reforços laterais", "LED IP65 anti-ofuscamento", "Cores personalizadas"],
    specs: ["Aço galvanizado a quente", "Dupla pintura eletrostática", "Fixações em inox 304"],
    thumbnail: "/assets/courts/indoor-pro.jpg",
  },
  {
    id: "outdoor-premium",
    name: "Quadra Outdoor Premium",
    subtitle: "Alta durabilidade para intempéries + gradil 4 mm 50×50",
    priceStart: "a partir de R$ 159.000",
    leadTime: "Instalação em 30–60 dias",
    highlights: ["Tratamento anticorrosão total", "Grama 12 mm alta densidade", "LED IP65 ~300 lux", "Baixa manutenção"],
    specs: ["Vidros 12 mm", "Pintura eletrostática dupla", "Acessórios em inox 304"],
    thumbnail: "/assets/courts/outdoor-premium.jpg",
  },
  {
    id: "club-kit",
    name: "Kit Club (2–4 quadras)",
    subtitle: "Solução completa para clubes e condomínios",
    priceStart: "sob consulta",
    leadTime: "Projeto e obra acompanhados",
    highlights: ["Projeto executivo", "Cronograma de obra", "Treinamento de equipe", "Plano de manutenção"],
    specs: ["Indoor/Outdoor", "Iluminação e sinalização", "Personalização visual"],
    thumbnail: "/assets/courts/club-kit.jpg",
  },
];

function ProductCard({ p, onQuote }) {
  return (
    <div className="glass" style={{ padding: 14, display: "grid", gap: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontWeight: 800 }}>{p.name}</div>
        <span className="badge">{p.leadTime}</span>
      </div>

      {p.thumbnail ? (
        <img
          src={p.thumbnail}
          alt={p.name}
          style={{ width: "100%", height: 160, objectFit: "cover", borderRadius: 10, border: "1px solid var(--border)" }}
        />
      ) : (
        <div style={{ height: 160, borderRadius: 10, border: "1px solid var(--border)", background: "linear-gradient(135deg, rgba(255,122,0,.12), rgba(255,122,0,.06))", display: "grid", placeItems: "center", color: "var(--muted)" }}>
          Imagem indisponível
        </div>
      )}

      <div className="small" style={{ color: "var(--muted)" }}>{p.subtitle}</div>

      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
        {p.highlights.map((h, i) => <span key={`h-${p.id}-${i}`} className="badge">{h}</span>)}
      </div>

      <div className="small" style={{ display: "grid", gap: 4 }}>
        {p.specs.map((s, i) => <div key={`s-${p.id}-${i}`}>• {s}</div>)}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: 4 }}>
        <div style={{ fontWeight: 800 }}>{p.priceStart}</div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-primary" onClick={() => onQuote(p)}>Quero um orçamento</button>
        </div>
      </div>
    </div>
  );
}

export default function Quadras() {
  const { user } = useAuth();
  const toast = useToast();
  const nav = useNavigate();
  const location = useLocation();

  function onRequestQuote(product) {
    if (!user) {
      saveFrom(location);
      toast.info("Entre na sua conta para solicitar um orçamento.");
      nav("/login", { state: { mode: "signin", from: { pathname: "/contato", state: { subject: `Orçamento: ${product?.name || "Quadra"}`, productId: product?.id } } } });
      return;
    }
    nav("/contato", { state: { subject: `Orçamento: ${product?.name || "Quadra"}`, productId: product?.id } });
  }

  return (
    <div className="section">
      <div className="container">

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 120, damping: 18 }}
          className="card"
          style={{ padding: 24, display: "grid", gap: 12 }}
        >
          <div className="h1">Quadras de Padel à venda</div>
          <div className="small" style={{ color: "var(--muted)" }}>
            Estrutura em aço galvanizado a quente, <strong>pintura eletrostática dupla</strong>, <strong>vidro 12 mm</strong> certificado e <strong>inox 304</strong> nas fixações. Personalize cores e sinalização.
          </div>
        </motion.div>

        <div className="card mt-3">
          <div className="h2">Nossas opções</div>
          <div className="grid grid-3 mt-2">
            {COURTS.map((p) => (
              <ProductCard key={p.id} p={p} onQuote={onRequestQuote} />
            ))}
          </div>
        </div>

        <div className="card mt-3">
          <div className="h2">Diferenciais técnicos</div>
          <div className="grid grid-3 mt-2">
            <div className="glass" style={{ padding: 14 }}>
              <div style={{ fontWeight: 800 }}>Vidro 12 mm certificado</div>
              <div className="small" style={{ color: "var(--muted)" }}>
                Temperado 12 mm (EN 12150-1 e outros padrões). Segurança e durabilidade, com menor taxa de autoquebra.
              </div>
            </div>
            <div className="glass" style={{ padding: 14 }}>
              <div style={{ fontWeight: 800 }}>Galvanização + dupla pintura</div>
              <div className="small" style={{ color: "var(--muted)" }}>
                Anti-corrosão real + acabamento premium. Cores personalizadas e brilho estável ao longo dos anos.
              </div>
            </div>
            <div className="glass" style={{ padding: 14 }}>
              <div style={{ fontWeight: 800 }}>Fixações em inox 304</div>
              <div className="small" style={{ color: "var(--muted)" }}>
                Parafusos e acessórios inox resistem à oxidação e mantêm a rigidez do conjunto.
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

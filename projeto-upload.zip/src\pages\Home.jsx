// src/pages/Home.jsx
import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext.jsx";
import * as fb from "../lib/firebase";
const { db } = fb;

import {
  collection,
  onSnapshot,
  orderBy,
  query,
  where,
} from "firebase/firestore";

/* ===== Helpers de data/horários ===== */
function startOfDay(d) { const x=new Date(d); x.setHours(0,0,0,0); return x; }
function toDateKey(d){ const y=d.getFullYear(); const m=String(d.getMonth()+1).padStart(2,"0"); const day=String(d.getDate()).padStart(2,"0"); return `${y}-${m}-${day}`; }
function keyToFloat(slotKey){ const [hh,mm]=slotKey.split(":").map(n=>parseInt(n,10)||0); return hh + mm/60; }
function makeDateAt(d, f){ const h=Math.floor(f); const m=Math.round((f-h)*60); const x=new Date(d); x.setHours(h,m,0,0); return x; }

/* ===== Guardar origem para retorno pós-login ===== */
function saveFrom(location){
  const from = { pathname: location.pathname, search: location.search, hash: location.hash, state: location.state ?? null };
  try { sessionStorage.setItem("auth.from", JSON.stringify(from)); } catch {}
  return from;
}

/* ===== Catálogo — Quadras Premium (vitrine) ===== */
const COURTS = [
  {
    id: "indoor-pro",
    name: "Quadra Indoor Pro",
    subtitle: "Estrutura galvanizada a quente + pintura eletrostática dupla, vidro 12 mm certificado",
    priceStart: "a partir de R$ 189.000",
    leadTime: "Instalação em 30–60 dias",
    highlights: ["Vidro 12 mm (EN 12150-1)", "Estrutura com reforços laterais", "LED IP65 anti-ofuscamento", "Cores personalizadas"],
    specs: ["Aço galvanizado a quente", "Dupla pintura eletrostática", "Fixações em inox 304"],
    thumbnail: "/assets/courts/indoor-pro.jpg",
  },
  {
    id: "outdoor-premium",
    name: "Quadra Outdoor Premium",
    subtitle: "Alta durabilidade para intempéries + gradil 4 mm 50×50",
    priceStart: "a partir de R$ 159.000",
    leadTime: "Instalação em 30–60 dias",
    highlights: ["Tratamento anticorrosão total", "Grama 12 mm alta densidade", "LED IP65 ~300 lux", "Baixa manutenção"],
    specs: ["Vidros 12 mm", "Pintura eletrostática dupla", "Acessórios em inox 304"],
    thumbnail: "/assets/courts/outdoor-premium.jpg",
  },
  {
    id: "club-kit",
    name: "Kit Club (2–4 quadras)",
    subtitle: "Solução completa para clubes e condomínios",
    priceStart: "sob consulta",
    leadTime: "Projeto e obra acompanhados",
    highlights: ["Projeto executivo", "Cronograma de obra", "Treinamento de equipe", "Plano de manutenção"],
    specs: ["Indoor/Outdoor", "Iluminação e sinalização", "Personalização visual"],
    thumbnail: "/assets/courts/club-kit.jpg",
  },
];

/* ===== Subcomponentes ===== */
function Feature({ icon, title, text }) {
  return (
    <div className="glass" style={{ padding: 16, display: "grid", gap: 6 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span aria-hidden="true">{icon}</span>
        <div style={{ fontWeight: 800 }}>{title}</div>
      </div>
      <div className="small" style={{ color: "var(--muted)" }}>{text}</div>
    </div>
  );
}

function ProductCard({ p, onQuote }) {
  return (
    <div className="glass" style={{ padding: 14, display: "grid", gap: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontWeight: 800 }}>{p.name}</div>
        <span className="badge">{p.leadTime}</span>
      </div>

      {p.thumbnail ? (
        <img
          src={p.thumbnail}
          alt={p.name}
          style={{ width: "100%", height: 160, objectFit: "cover", borderRadius: 10, border: "1px solid var(--border)" }}
        />
      ) : (
        <div style={{ height: 160, borderRadius: 10, border: "1px solid var(--border)", background: "linear-gradient(135deg, rgba(255,122,0,.12), rgba(255,122,0,.06))", display: "grid", placeItems: "center", color: "var(--muted)" }}>
          Imagem indisponível
        </div>
      )}

      <div className="small" style={{ color: "var(--muted)" }}>{p.subtitle}</div>

      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
        {p.highlights.map((h, i) => <span key={`h-${p.id}-${i}`} className="badge">{h}</span>)}
      </div>

      <div className="small" style={{ display: "grid", gap: 4 }}>
        {p.specs.map((s, i) => <div key={`s-${p.id}-${i}`}>• {s}</div>)}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: 4 }}>
        <div style={{ fontWeight: 800 }}>{p.priceStart}</div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-primary" onClick={() => onQuote(p)}>Quero um orçamento</button>
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const { user, isAdmin } = useAuth();
  const toast = useToast();
  const nav = useNavigate();
  const location = useLocation();

  const [todayEvents, setTodayEvents] = useState({});
  const [myTodayReservations, setMyTodayReservations] = useState({});
  const [loadingEvents, setLoadingEvents] = useState(false);
  const [loadingResv, setLoadingResv] = useState(false);

  const today = startOfDay(new Date());
  const todayKey = toDateKey(today);

  /* ===== Eventos de hoje (apenas se logado, pelas regras) ===== */
  useEffect(() => {
    if (!user) { setTodayEvents({}); return; }
    setLoadingEvents(true);
    const q = query(collection(db, "events", todayKey, "slots"));
    const unsub = onSnapshot(q, {
      next: (snap) => {
        const map = {}; snap.forEach(d => map[d.id] = d.data());
        setTodayEvents(map);
        setLoadingEvents(false);
      },
      error: (err) => {
        console.warn("home events listener:", err.code, err.message);
        setTodayEvents({});
        setLoadingEvents(false);
      }
    });
    return () => unsub();
  }, [user, todayKey]);

  /* ===== Minhas reservas de hoje (apenas se logado) ===== */
  useEffect(() => {
    if (!user) { setMyTodayReservations({}); return; }
    setLoadingResv(true);
    const q = query(
      collection(db, "reservations", todayKey, "slots"),
      where("uid", "==", user.uid),
      orderBy("startAt", "asc")
    );
    const unsub = onSnapshot(q, {
      next: (snap) => {
        const map = {}; snap.forEach(d => map[d.id] = d.data());
        setMyTodayReservations(map);
        setLoadingResv(false);
      },
      error: (err) => {
        console.warn("home reservations listener:", err.code, err.message);
        setMyTodayReservations({});
        setLoadingResv(false);
      }
    });
    return () => unsub();
  }, [user, todayKey]);

  const sortedEvents = useMemo(() => {
    const now = new Date();
    return Object.entries(todayEvents)
      .map(([slotKey, evt]) => {
        const ts = evt.slotStartAt?.toDate ? evt.slotStartAt.toDate() : (evt.slotStartAt || makeDateAt(today, keyToFloat(slotKey)));
        return { slotKey, ...evt, _start: ts };
      })
      .filter(e => e._start.getTime() >= now.getTime())
      .sort((a, b) => a._start - b._start);
  }, [todayEvents, today]);

  const myResvList = useMemo(() => {
    return Object.entries(myTodayReservations)
      .map(([slotKey, r]) => ({ slotKey, ...r }))
      .sort((a, b) => {
        const ta = a.startAt?.toDate ? a.startAt.toDate() : a.startAt;
        const tb = b.startAt?.toDate ? b.startAt.toDate() : b.startAt;
        return (ta?.getTime?.() || 0) - (tb?.getTime?.() || 0);
      });
  }, [myTodayReservations]);

  /* ===== CTA handlers ===== */
  function goAgendar() {
    nav("/agendamento");
  }
  function goLogin() {
    saveFrom(location);
    nav("/login");
  }
  function goAdmin() {
    nav("/admin");
  }
  function onRequestQuote(product) {
    if (!user) {
      saveFrom(location);
      toast.info("Entre na sua conta para solicitar um orçamento.");
      nav("/login", { state: { mode: "signin", from: { pathname: "/contato", state: { subject: `Orçamento: ${product?.name || "Quadra"}`, productId: product?.id } } } });
      return;
    }
    try {
      nav("/contato", { state: { subject: `Orçamento: ${product?.name || "Quadra"}`, productId: product?.id } });
    } catch {
      toast.info("Recebemos seu interesse. Fale com a gente no menu Contato!");
    }
  }

  return (
    <div className="section">
      <div className="container">

        {/* HERO – foco em venda de quadras premium */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 120, damping: 18 }}
          className="card"
          style={{
            padding: 24,
            display: "grid",
            gap: 16,
            background: "linear-gradient(135deg, rgba(255,122,0,.12), rgba(255,122,0,.03))",
            border: "1px solid var(--border)"
          }}
        >
          <div style={{ display: "grid", gap: 8 }}>
            <div className="h1" style={{ marginBottom: 2 }}>
              Quadras de Padel Premium — do projeto à entrega, sem atalhos
            </div>
            <div className="small" style={{ color: "var(--muted)" }}>
              Execução completa: projeto executivo, base alinhada e nivelada, estrutura em aço galvanizado a quente, <strong>pintura eletrostática dupla</strong> na cor que você escolher, <strong>vidro 12 mm certificado</strong> e acessórios em <strong>inox 304</strong>. Mais segurança, durabilidade e valor para o seu espaço.
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button className="btn btn-primary" onClick={() => onRequestQuote(COURTS[0])}>
              Solicitar orçamento
            </button>
            <button className="btn" onClick={goAgendar}>
              Agendar horário (aluguel)
            </button>
            {!user && (
              <button className="btn" onClick={goLogin}>
                Entrar
              </button>
            )}
            {user && isAdmin && (
              <button className="btn" onClick={goAdmin}>
                Painel do Admin
              </button>
            )}
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <span className="badge">Garantia estendida</span>
            <span className="badge">Instalação 30–60 dias</span>
            <span className="badge">Cores personalizadas</span>
            <span className="badge">Certificações internacionais</span>
          </div>
        </motion.div>

        {/* Diferenciais de engenharia */}
        <div className="card mt-3">
          <div className="h2">Por que nossas quadras?</div>
          <div className="grid grid-3 mt-2">
            <Feature
              icon="🏗️"
              title="Projeto & execução completos"
              text="Do briefing ao projeto executivo, com cronograma e checklist. Base alinhada e nivelada por profissionais experientes."
            />
            <Feature
              icon="🛡️"
              title="Estrutura superior"
              text="Aço galvanizado a quente + dupla pintura eletrostática. Reforços laterais para rigidez e estabilidade em jogo."
            />
            <Feature
              icon="🔩"
              title="Fixações em inox 304"
              text="Parafusos e acessórios em inox 304 garantem durabilidade, resistência à oxidação e acabamento premium."
            />
          </div>

          <div className="grid grid-3 mt-2">
            <Feature
              icon="🪟"
              title="Vidro 12 mm certificado"
              text="Não abrimos mão de 12 mm temperado (EN 12150-1 e outros padrões). Mais segurança e vida útil."
            />
            <Feature
              icon="🧱"
              title="Gradil premium"
              text="Arame 4 mm, malha 50×50, galvanizado a quente + pintura eletrostática dupla. Superfície lisa, sem rebarbas."
            />
            <Feature
              icon="💡"
              title="Iluminação de jogo"
              text="LED IP65 ~300 lux com foco anti-ofuscamento para partidas noturnas confortáveis."
            />
          </div>
        </div>

        {/* Grama Sintética — resumo técnico curado */}
        <div className="card mt-3">
          <div className="h2">Grama sintética premium 12 mm</div>
          <div className="small" style={{ color: "var(--muted)" }}>
            Monofilamento reforçado “estilo Mondo”, <strong>12 mm</strong>, <strong>9.500 Dtex</strong>, bitola <strong>3/16"</strong>, <strong>58.800 fios/m²</strong>, backing <strong>PP+PP+SBR</strong> (3 camadas). PE linear de alta qualidade com processo KDK mantém cor e curvatura; base em <strong>sarja dupla</strong> aumenta resistência a rasgos; adesivo de baixa toxicidade e antimofos. A altura de 12 mm ajuda a <em>“travar”</em> o enchimento e prolongar a vida útil. Cores azul ou verde (customizáveis).
          </div>
        </div>

        {/* Vitrine — Nossas quadras */}
        <div className="card mt-3">
          <div className="h2">Nossas quadras</div>
          <div className="small" style={{ color: "var(--muted)" }}>
            Personalizamos estrutura, iluminação e acabamento para o seu clube, condomínio ou academia.
          </div>

          <div className="grid grid-3 mt-2">
            {COURTS.map((p) => (
              <ProductCard key={p.id} p={p} onQuote={onRequestQuote} />
            ))}
          </div>
        </div>

        {/* Processo em 4 etapas */}
        <div className="card mt-3">
          <div className="h2">Como funciona</div>
          <div className="grid grid-4 mt-2">
            <div className="glass" style={{ padding: 14 }}>
              <div className="badge">1</div>
              <div style={{ fontWeight: 800, marginTop: 6 }}>Briefing</div>
              <div className="small" style={{ color: "var(--muted)" }}>Visita técnica, medição e plano de obra.</div>
            </div>
            <div className="glass" style={{ padding: 14 }}>
              <div className="badge">2</div>
              <div style={{ fontWeight: 800, marginTop: 6 }}>Projeto executivo</div>
              <div className="small" style={{ color: "var(--muted)" }}>Layout, cargas, memorial e cronograma.</div>
            </div>
            <div className="glass" style={{ padding: 14 }}>
              <div className="badge">3</div>
              <div style={{ fontWeight: 800, marginTop: 6 }}>Obra & instalação</div>
              <div className="small" style={{ color: "var(--muted)" }}>Base nivelada, estrutura, vidros, grama e LED.</div>
            </div>
            <div className="glass" style={{ padding: 14 }}>
              <div className="badge">4</div>
              <div style={{ fontWeight: 800, marginTop: 6 }}>Entrega & treinamento</div>
              <div className="small" style={{ color: "var(--muted)" }}>Checklist, manutenção e suporte.</div>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 10 }}>
            <button className="btn btn-primary" onClick={() => onRequestQuote(COURTS[0])}>Quero um orçamento</button>
          </div>
        </div>

        {/* Comparativo rápido */}
        <div className="card mt-3">
          <div className="h2">Nosso padrão x padrões comuns</div>
          <div className="grid grid-2 mt-2">
            <div className="glass" style={{ padding: 14 }}>
              <div style={{ fontWeight: 800, marginBottom: 6 }}>Nós</div>
              <div className="small" style={{ color: "var(--muted)" }}>
                • Ligações do vidro em <strong>inox 304</strong><br/>
                • <strong>Vidro 12 mm</strong> certificado (EN 12150-1)<br/>
                • <strong>Galvanização a quente</strong> + <strong>dupla pintura</strong><br/>
                • Furação e corte CNC (encaixe perfeito, instalação mais rápida)<br/>
                • Gradil 4 mm 50×50 com pintura eletrostática dupla
              </div>
            </div>
            <div className="glass" style={{ padding: 14 }}>
              <div style={{ fontWeight: 800, marginBottom: 6 }}>Outros</div>
              <div className="small" style={{ color: "var(--muted)" }}>
                • Parafusos e suportes em ferro comum (oxida)<br/>
                • Vidro 10 mm ou sem certificação clara<br/>
                • Pintura simples, sem galvanização adequada<br/>
                • Ajustes manuais demorados e menos precisos<br/>
                • Gradil fino, sem acabamento premium
              </div>
            </div>
          </div>
        </div>

        {/* Depoimentos (estático) */}
        <div className="card mt-3">
          <div className="h2">O que dizem nossos clientes</div>
          <div className="grid grid-3 mt-2">
            <div className="glass" style={{ padding: 16 }}>
              <div style={{ fontWeight: 800 }}>“Qualidade impecável.”</div>
              <div className="small" style={{ color: "var(--muted)" }}>A quadra elevou o padrão do clube e trouxe novos alunos.</div>
              <div className="small" style={{ marginTop: 6 }}>— Gestor de clube, SP</div>
            </div>
            <div className="glass" style={{ padding: 16 }}>
              <div style={{ fontWeight: 800 }}>“Instalação rápida.”</div>
              <div className="small" style={{ color: "var(--muted)" }}>Obra limpa e dentro do prazo combinado.</div>
              <div className="small" style={{ marginTop: 6 }}>— Síndico, RJ</div>
            </div>
            <div className="glass" style={{ padding: 16 }}>
              <div style={{ fontWeight: 800 }}>“Excelente iluminação.”</div>
              <div className="small" style={{ color: "var(--muted)" }}>Jogos noturnos com visibilidade perfeita.</div>
              <div className="small" style={{ marginTop: 6 }}>— Academia, PR</div>
            </div>
          </div>
        </div>

        {/* Bloco operacional — Agendamento (mantido) */}
        <div className="card mt-3">
          <div className="h2">Quer só jogar hoje?</div>
          <div className="small" style={{ color: "var(--muted)" }}>
            Além de vender e instalar quadras premium, você pode <strong>alugar horários</strong> na nossa estrutura atual.
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 10 }}>
            <button className="btn" onClick={goAgendar}>Agendar horário</button>
          </div>
        </div>

        {/* Eventos de hoje (apenas logado, pelas suas regras) */}
        <div className="card mt-3">
          <div className="h2">Eventos de hoje</div>
          {!user ? (
            <div className="small" style={{ color: "var(--muted)" }}>
              Faça login para ver os eventos de hoje.
            </div>
          ) : loadingEvents ? (
            <div className="small" style={{ color: "var(--muted)" }}>Carregando…</div>
          ) : sortedEvents.length === 0 ? (
            <div className="small" style={{ color: "var(--muted)" }}>Nenhum evento programado para hoje.</div>
          ) : (
            <div className="grid grid-3 mt-2">
              {sortedEvents.map(evt => (
                <div key={evt.slotKey} className="glass" style={{ padding: 12, display: "grid", gap: 8 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div style={{ fontWeight: 800 }}>{evt.title || "Evento"}</div>
                    <span className="badge">{evt.slotKey}</span>
                  </div>
                  {evt.imageUrl ? (
                    <img
                      src={evt.imageUrl}
                      alt={evt.title || "Evento"}
                      style={{ width: "100%", height: 120, objectFit: "cover", borderRadius: 10, border: "1px solid var(--border)" }}
                    />
                  ) : (
                    <div style={{ height: 120, borderRadius: 10, border: "1px solid var(--border)", background: "linear-gradient(135deg, rgba(255,122,0,.12), rgba(255,122,0,.06))", display: "grid", placeItems: "center", color: "var(--muted)" }}>
                      Sem imagem
                    </div>
                  )}
                  <div className="small" style={{ color: "var(--muted)" }}>
                    {evt.rules || "—"}
                  </div>
                  <div className="small">
                    <strong>Quando:</strong> {evt._start.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                  </div>
                  <div style={{ display: "flex", justifyContent: "flex-end" }}>
                    <button className="btn" onClick={goAgendar}>Ver no agendamento</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Minhas reservas de hoje (apenas logado) */}
        <div className="card mt-3">
          <div className="h2">Minhas reservas de hoje</div>
          {!user ? (
            <div className="small" style={{ color: "var(--muted)" }}>
              Entre na sua conta para ver suas reservas.
            </div>
          ) : loadingResv ? (
            <div className="small" style={{ color: "var(--muted)" }}>Carregando…</div>
          ) : myResvList.length === 0 ? (
            <div className="small" style={{ color: "var(--muted)" }}>
              Você não tem reservas hoje. Que tal agendar agora?
            </div>
          ) : (
            <div className="grid grid-3 mt-2">
              {myResvList.map(r => {
                const startAt = r.startAt?.toDate ? r.startAt.toDate() : r.startAt;
                const hh = startAt instanceof Date ? String(startAt.getHours()).padStart(2, "0") : "--";
                const mm = startAt instanceof Date ? String(startAt.getMinutes()).padStart(2, "0") : "--";
                return (
                  <div key={r.slotKey} className="glass" style={{ padding: 12, display: "grid", gap: 6 }}>
                    <div style={{ fontWeight: 800 }}>{hh}:{mm}</div>
                    <div className="small" style={{ color: "var(--muted)" }}>Reserva confirmada</div>
                    <div style={{ display: "flex", justifyContent: "flex-end" }}>
                      <button className="btn" onClick={goAgendar}>Gerenciar</button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

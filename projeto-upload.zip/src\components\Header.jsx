import { useEffect, useMemo, useRef, useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext.jsx";
import * as fb from "../lib/firebase";
const { db, auth, signOut } = fb;

import { doc, onSnapshot } from "firebase/firestore";

/* Guarda a rota atual para retorno pós-login */
function saveFrom(location) {
  const from = {
    pathname: location.pathname,
    search: location.search,
    hash: location.hash,
    state: location.state ?? null,
  };
  try { sessionStorage.setItem("auth.from", JSON.stringify(from)); } catch {}
  return from;
}

function Logo() {
  return (
    <NavLink
      to="/"
      className="logo"
      style={{ display: "flex", alignItems: "center", gap: 12, textDecoration: "none" }}
      aria-label="Reserva Padel — Início"
    >
      {/* Ícone minimalista (bola/curva) */}
      <svg width="28" height="28" viewBox="0 0 24 24" aria-hidden="true">
        <circle cx="12" cy="12" r="11" fill="currentColor" opacity=".10"/>
        <path d="M6.5 15.2c2.9-1.5 8.1-1.5 11 0" stroke="currentColor" strokeWidth="1.5" fill="none" />
        <path d="M6 9.25h12" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      </svg>

      {/* Wordmark épico */}
      <span
        className="wordmark-epic"
        style={{
          fontWeight: 900,
          letterSpacing: 0.4,
          fontSize: 18,
          lineHeight: 1,
          display: "inline-block",
          backgroundImage:
            "linear-gradient(90deg,#FFE082 0%,#FFC107 22%,#FF8F00 48%,#FF6F00 72%,#FF3D00 100%)",
          backgroundSize: "200% auto",
          WebkitBackgroundClip: "text",
          backgroundClip: "text",
          color: "transparent",
          filter: "drop-shadow(0 2px 8px rgba(255, 140, 0, .25))",
          transform: "translateY(1px)",
          whiteSpace: "nowrap",
        }}
        title="Reserva Padel"
      >
        Reserva Padel
      </span>
    </NavLink>
  );
}


function NavItem({ to, children, onClick }) {
  return (
    <NavLink
      to={to}
      onClick={onClick}
      className={({ isActive }) =>
        "nav-item" + (isActive ? " active" : "")
      }
      style={({ isActive }) => ({
        padding: "8px 10px",
        borderRadius: 10,
        color: "var(--fg)",
        textDecoration: "none",
        background: isActive ? "rgba(255,255,255,.06)" : "transparent",
        border: "1px solid " + (isActive ? "rgba(255,255,255,.08)" : "transparent")
      })}
    >
      {children}
    </NavLink>
  );
}

export default function Header() {
  const { user } = useAuth();
  const toast = useToast();
  const nav = useNavigate();
  const location = useLocation();

  const [mobileOpen, setMobileOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  // Fecha menu mobile quando a rota muda
  useEffect(() => { setMobileOpen(false); }, [location.pathname]);

  // Observa /admins/{uid} somente se logado (regras exigem isSignedIn)
  useEffect(() => {
    if (!user?.uid) { setIsAdmin(false); return; }
    const ref = doc(db, "admins", user.uid);
    const unsub = onSnapshot(ref, (snap) => {
      setIsAdmin(snap.exists());
    }, () => setIsAdmin(false));
    return () => unsub();
  }, [user?.uid]);

  function goLogin(mode) {
    saveFrom(location);
    nav("/login", { state: { mode } });
  }

  async function doSignOut() {
    try {
      await signOut();
      toast.success("Você saiu da sua conta.");
      nav("/", { replace: true });
    } catch (e) {
      console.error(e);
      toast.error("Não foi possível sair agora.");
    }
  }

  function ctaOrcamento() {
    if (!user) {
      saveFrom(location);
      nav("/login", {
        state: {
          mode: "signin",
          from: { pathname: "/contato", state: { subject: "Orçamento: Quadra de Padel", productId: "orcamento-geral" } }
        }
      });
      return;
    }
    nav("/contato", { state: { subject: "Orçamento: Quadra de Padel", productId: "orcamento-geral" } });
  }

  const avatarLetter = useMemo(() => {
    if (!user) return "–";
    const base = user.displayName || user.email || "Você";
    return (base.trim()[0] || "V").toUpperCase();
  }, [user]);

  return (
    <header
      style={{
        position: "sticky",
        top: 0,
        zIndex: 50,
        backdropFilter: "saturate(1.2) blur(10px)",
        background: "linear-gradient(180deg, rgba(12,12,12,.75), rgba(12,12,12,.45))",
        borderBottom: "1px solid rgba(255,255,255,.08)"
      }}
    >
      <div className="container" style={{ display: "flex", alignItems: "center", height: 64, gap: 14 }}>
        <Logo />

        {/* Desktop nav */}
        <nav className="hide-sm" style={{ display: "flex", alignItems: "center", gap: 8, marginLeft: 16 }}>
          <NavItem to="/">Início</NavItem>
          <NavItem to="/quadras">Quadras</NavItem>
          <NavItem to="/agendamento">Agendamento</NavItem>
          <NavItem to="/sobre">Sobre</NavItem>
          <NavItem to="/contato">Contato</NavItem>
        </nav>

        {/* CTA — foco em venda */}
        <div className="hide-sm" style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
          <button className="btn btn-primary" onClick={ctaOrcamento}>
            Solicitar orçamento
          </button>

          {!user ? (
            <>
              <button className="btn" onClick={() => goLogin("signin")}>Entrar</button>
              <button className="btn" onClick={() => goLogin("signup")}>Criar conta</button>
            </>
          ) : (
            <div style={{ position: "relative" }}>
              <details>
                <summary
                  style={{
                    listStyle: "none",
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    cursor: "pointer",
                  }}
                >
                  <div
                    style={{
                      width: 34, height: 34, borderRadius: "50%",
                      background: "linear-gradient(135deg, rgba(255,255,255,.12), rgba(255,255,255,.06))",
                      border: "1px solid var(--border)",
                      display: "grid", placeItems: "center",
                      fontWeight: 800
                    }}
                  >
                    {avatarLetter}
                  </div>
                  <span className="small" style={{ color: "var(--muted)" }}>
                    {user.displayName || user.email}
                  </span>
                </summary>
                <div
                  className="glass"
                  style={{
                    position: "absolute",
                    right: 0,
                    marginTop: 8,
                    minWidth: 220,
                    padding: 8,
                    borderRadius: 12,
                    border: "1px solid var(--border)",
                    display: "grid",
                    gap: 4
                  }}
                >
                  {isAdmin && (
                    <NavLink to="/admin" className="btn" style={{ textAlign: "left" }}>
                      Admin
                    </NavLink>
                  )}
                  <NavLink to="/agendamento" className="btn" style={{ textAlign: "left" }}>
                    Meus agendamentos
                  </NavLink>
                  <button className="btn" onClick={doSignOut} style={{ textAlign: "left" }}>
                    Sair
                  </button>
                </div>
              </details>
            </div>
          )}
        </div>

        {/* Mobile toggle */}
        <button
          className="show-sm btn"
          aria-label="Abrir menu"
          onClick={() => setMobileOpen(v => !v)}
          style={{ marginLeft: "auto" }}
        >
          ☰
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ type: "tween", duration: .2 }}
            className="container show-sm"
            style={{ overflow: "hidden" }}
          >
            <div className="card" style={{ padding: 12, display: "grid", gap: 8 }}>
              <NavItem to="/" onClick={() => setMobileOpen(false)}>Início</NavItem>
              <NavItem to="/quadras" onClick={() => setMobileOpen(false)}>Quadras</NavItem>
              <NavItem to="/agendamento" onClick={() => setMobileOpen(false)}>Agendamento</NavItem>
              <NavItem to="/sobre" onClick={() => setMobileOpen(false)}>Sobre</NavItem>
              <NavItem to="/contato" onClick={() => setMobileOpen(false)}>Contato</NavItem>

              <div style={{ display: "flex", gap: 8, marginTop: 6, flexWrap: "wrap" }}>
                <button className="btn btn-primary" onClick={() => { setMobileOpen(false); ctaOrcamento(); }}>
                  Solicitar orçamento
                </button>

                {!user ? (
                  <>
                    <button className="btn" onClick={() => { setMobileOpen(false); goLogin("signin"); }}>Entrar</button>
                    <button className="btn" onClick={() => { setMobileOpen(false); goLogin("signup"); }}>Criar conta</button>
                  </>
                ) : (
                  <>
                    {isAdmin && (
                      <NavLink to="/admin" className="btn" onClick={() => setMobileOpen(false)}>
                        Admin
                      </NavLink>
                    )}
                    <button className="btn" onClick={() => { setMobileOpen(false); doSignOut(); }}>
                      Sair
                    </button>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
